<?php

namespace Modules\OpenAI\Database\Seeders\versions\v1_1_0;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MenuItemsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        DB::table('menu_items')->where(['label' => 'All Templates', 'link' => 'use-cases'])->update([
            'params' => '{"permission":"Modules\\\\OpenAI\\\\Http\\\\Controllers\\\\Admin\\\\UseCasesController@index","route_name":["admin.use_case.create", "admin.use_case.list", "admin.use_case.edit"]}',
        ]);

    }
}
