<?php

namespace Database\Seeders\versions\v1_1_0;

use Illuminate\Database\Seeder;

class PermissionsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        
        \DB::table('permissions')->insert(array (
          
            446 => 
            array (
                'controller_name' => 'ChatController',
                'controller_path' => 'Modules\\OpenAI\\Http\\Controllers\\Customer\\ChatController',
                'method_name' => 'history',
                'name' => 'Modules\\OpenAI\\Http\\Controllers\\Customer\\ChatController@history',
            ),
            447 => 
            array (
                'controller_name' => 'ChatController',
                'controller_path' => 'Modules\\OpenAI\\Http\\Controllers\\Customer\\ChatController',
                'method_name' => 'delete',
                'name' => 'Modules\\OpenAI\\Http\\Controllers\\Customer\\ChatController@delete',
            ),
            448 => 
            array (
                'controller_name' => 'ChatController',
                'controller_path' => 'Modules\\OpenAI\\Http\\Controllers\\Customer\\ChatController',
                'method_name' => 'update',
                'name' => 'Modules\\OpenAI\\Http\\Controllers\\Customer\\ChatController@update',
            ),
            449 =>
            array (
                'controller_name' => 'UseCasesController',
                'controller_path' => 'Modules\\OpenAI\\Http\\Controllers\\Admin\\UseCasesController',
                'method_name' => 'create',
                'name' => 'Modules\\OpenAI\\Http\\Controllers\\Admin\\UseCasesController@create',
            )
        ));
        
        
    }
}